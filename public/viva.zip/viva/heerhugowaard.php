<?php
	$current = 'heerhugowaard';
	require './partials/content.php';
?>