<?php
	$current = 'beverH3';
	require './partials/content.php';
?>