<?php
	$current = 'caslimakC3';
	require './partials/content.php';
?>