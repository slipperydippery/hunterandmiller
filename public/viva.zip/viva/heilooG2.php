<?php
	$current = 'heilooG2';
	require './partials/content.php';
?>