<?php
	$current = 'heilooC3';
	require './partials/content.php';
?>