<?php
	$current = 'heemskerkE4';
	require './partials/content.php';
?>