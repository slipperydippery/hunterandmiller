<?php
	$current = 'heemskerkD0';
	require './partials/content.php';
?>