<?php
	$page_name = "Beverwijk - Waterrijck";
	$cookie_name = "beverwijk";
	$cookie_value = "waterrijck"
?>

<?php
	include "cookiecode.php";
	include "index.php";
?>