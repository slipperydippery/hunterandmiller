<?php
	$current = 'heemskerkE1';
	require './partials/content.php';
?>