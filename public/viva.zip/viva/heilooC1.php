<?php
	$current = 'heilooC1';
	require './partials/content.php';
?>