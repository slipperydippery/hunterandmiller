			
		</div>
	</div>
</div>
<div class="wrapper" id="footer">
	<div class="layout">
		<div class="footer">
			<div class="top">
				<div class="copyright">
					<a href="links-in-kolommen" class="first last ">© ViVa! Zorggroep 2015</a>
				</div>
				<div class="twitter">vivazorggroep: @ViVa_Leden gefeliciteerd !</div>
			</div>
			<div class="middle">
				<div class="footerBlock">
					<div class="title">Algemeen</div>
					<a href="over-viva/colofon" class="first ">Colofon</a>
					<a href="over-viva/disclaimer">Disclaimer</a>
					<a href="over-viva/privacy-en-geheimhouding">Privacy en geheimhouding</a>
					<a href="sitemap">Sitemap</a>
					<a href="uitgebreid-zoeken" class="last ">Uitgebreid zoeken</a>
				</div>
				<div class="footerBlock">
					<div class="title">Praktische informatie</div>
					<a href="wonen/aanvullende-diensten" class="first ">Aanvullende diensten</a>
					<a href="over-viva/mantelzorgbeleid">Mantelzorgbeleid</a>
					<a href="over-viva/werkgebied-en-sociale-kaart">Werkgebied en sociale kaart</a>
					<a href="wonen-bij-viva/indicaties">Zorgzwaartepakketten</a>
					<a href="wonen-bij-viva/ontruimen-appartement-na-overlijden-vertrek" class="last ">Ontruimen appartement na overlijden/vertrek</a>
					<a href="over-viva/hoe-verandert-mijn-zorg" class="last ">Hoe verandert mijn zorg?</a>
				</div>
				<div class="footerBlock intro">
					<div class="title">ViVa! Zorggroep</div>
					<div class="text"><p>Bij ViVa! Zorggroep kunt u terecht voor alle wensen en vragen op het gebied van wonen, welzijn en zorg.&nbsp;Er is &eacute;&eacute;n loket waar u snel geholpen wordt.&nbsp;</p> <p>&nbsp;</p> <p>Persoonlijke aandacht voor elke cli&euml;nt staat op de eerste...</p></div>
					<a href="viva-zorggroep.htm" class="more">Meer lezen</a>
				</div>
				<div class="footerBlock phone">
					<div class="title">Neem contact op met</div>
					<a class="phoneNumber" href="tel:088 - 995 80 00">088 - 995 80 00</a>
					<a class="more" href="over-viva/contact">
				Alle contactgegevens
			</a>
				</div>
				<div class="footerBlock news">
					<div class="title">Blijf op de hoogte</div>
					<div class="text"><p>Een aantal keer per jaar brengt ViVa! Zorggroep een informatieve nieuwsbrief uit voor haar cli&euml;nten.<br /><br /></p>
<p><a href="over-viva/nieuwsbrief-clienten">Download de nieuwsbrief.</a></p></div>
				</div>
			</div>
			<div class="bottom">
				<div class="keurmerkLinks">
					<div class="keurmerken">
						<a href="over-viva/kwaliteit/kwaliteitskeurmerk.htm">
							<img height="33" alt="HKZ" title="HKZ" src="https://www.vivazorggroep.nl/files/7/0/2/1/HKZ%20logo.jpg?height=33" />
						</a>
					</div>
					<div class="links">
						<a href="over-viva/anbi-gegevens" class="first ">ANBI</a>
						<a href="over-viva/leveringsvoorwaarden" class="last ">Leveringsvoorwaarden</a>
					</div>
				</div>
				<div class="social">
					<span>Volg ons op:</span>
					<a class="Facebook" href="https://www.facebook.com/viva.zorggroep" target="_blank"></a>
					<a class="Twitter" href="https://twitter.com/vivazorggroep" target="_blank"></a>
					<a class="LinkedIn" href="http://www.linkedin.com/company/viva-zorggroep" target="_blank"></a>
					<a class="Youtube" href="http://www.youtube.com/ViVaZorggroep" target="_blank"></a>
				</div>
			</div>
		</div>
	</div>
</div>	</div>
</body>
</html>
<!--
	Total Time: 0:00:00.074
	Total database access: 0:00:00.009
	Main Xsl transformation: 0:00:00.012
	code: 0:00:00.051
-->
