<h2 class="vim-infoblock-head">Mail verzonden</h2>

<p class="vim-contact-thanks"><i>Bedankt voor uw aanvraag, u hoort spoedig van ons!</i></p>

<div class="vim-contact-tel">
	<p>Heeft u nog vragen? <br /> U kunt altijd contact opnemen via <span>088 &#8211; 995 86 40</span> met de afdeling Zorgbemiddeling.</p>
</div>	
