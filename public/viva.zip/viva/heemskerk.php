<?php
	$current = 'heemskerk';
	require './partials/content.php';
?>