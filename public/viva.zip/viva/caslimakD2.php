<?php
	$current = 'caslimakD2';
	require './partials/content.php';
?>