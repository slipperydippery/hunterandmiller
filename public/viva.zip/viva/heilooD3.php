<?php
	$current = 'heilooD3';
	require './partials/content.php';
?>