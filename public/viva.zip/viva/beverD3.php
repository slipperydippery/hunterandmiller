<?php
	$current = 'beverD3';
	require './partials/content.php';
?>