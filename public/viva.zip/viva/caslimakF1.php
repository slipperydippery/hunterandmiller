<?php
	$current = 'caslimakF1';
	require './partials/content.php';
?>