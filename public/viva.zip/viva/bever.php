<?php
	$current = 'bever';
	require './partials/content.php';
?>