<?php
	$current = 'beverG1G2';
	require './partials/content.php';
?>