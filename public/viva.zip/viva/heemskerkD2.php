<?php
	$current = 'heemskerkD2';
	require './partials/content.php';
?>