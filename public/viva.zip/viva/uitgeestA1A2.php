<?php
	$current = 'uitgeestA1A2';
	require './partials/content.php';
?>