<?php
	$current = 'beverC1C2';
	require './partials/content.php';
?>