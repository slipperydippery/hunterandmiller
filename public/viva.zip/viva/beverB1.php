<?php
	$current = 'beverB1';
	require './partials/content.php';
?>