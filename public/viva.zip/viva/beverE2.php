<?php
	$current = 'beverE2';
	require './partials/content.php';
?>