<?php
	$current = 'beverA3';
	require './partials/content.php';
?>