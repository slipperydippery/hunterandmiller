<?php
	$current = 'uitgeestA2';
	require './partials/content.php';
?>