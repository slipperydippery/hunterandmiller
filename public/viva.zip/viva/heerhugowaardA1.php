<?php
	$current = 'heerhugowaardA1';
	require './partials/content.php';
?>