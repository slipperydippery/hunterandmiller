<?php
	$current = 'uitgeestC1C2';
	require './partials/content.php';
?>