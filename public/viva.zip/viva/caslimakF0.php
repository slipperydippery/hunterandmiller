<?php
	$current = 'caslimakF0';
	require './partials/content.php';
?>