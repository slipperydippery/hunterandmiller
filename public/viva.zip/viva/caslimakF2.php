<?php
	$current = 'caslimakF2';
	require './partials/content.php';
?>