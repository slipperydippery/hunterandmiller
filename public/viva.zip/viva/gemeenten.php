<?php
	$current = 'gemeenten';
	require './partials/content.php';
?>