<?php
	$current = 'beverA2';
	require './partials/content.php';
?>