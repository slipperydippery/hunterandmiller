<?php
	$current = 'caslimakA2';
	require './partials/content.php';
?>