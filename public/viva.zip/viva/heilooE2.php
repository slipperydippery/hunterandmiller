<?php
	$current = 'heilooE2';
	require './partials/content.php';
?>