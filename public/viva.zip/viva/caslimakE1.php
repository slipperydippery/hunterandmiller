<?php
	$current = 'caslimakE1';
	require './partials/content.php';
?>