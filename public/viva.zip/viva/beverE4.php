<?php
	$current = 'beverE4';
	require './partials/content.php';
?>