<?php
	$current = 'caslimakD1';
	require './partials/content.php';
?>