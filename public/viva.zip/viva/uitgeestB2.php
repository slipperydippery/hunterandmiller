<?php
	$current = 'uitgeestB2';
	require './partials/content.php';
?>