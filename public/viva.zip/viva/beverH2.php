<?php
	$current = 'beverH2';
	require './partials/content.php';
?>