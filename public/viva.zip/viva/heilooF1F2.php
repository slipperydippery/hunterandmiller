<?php
	$current = 'heilooF1F2';
	require './partials/content.php';
?>