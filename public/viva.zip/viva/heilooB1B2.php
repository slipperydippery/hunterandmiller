<?php
	$current = 'heilooB1B2';
	require './partials/content.php';
?>