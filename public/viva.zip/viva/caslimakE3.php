<?php
	$current = 'caslimakE3';
	require './partials/content.php';
?>