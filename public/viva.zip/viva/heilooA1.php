<?php
	$current = 'heilooA1';
	require './partials/content.php';
?>