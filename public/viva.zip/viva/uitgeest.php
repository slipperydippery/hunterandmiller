<?php
	$current = 'uitgeest';
	require './partials/content.php';
?>