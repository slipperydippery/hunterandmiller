<?php
	$current = 'caslimakG2';
	require './partials/content.php';
?>