here

<div class="vimeo-container">
    <a href="#" class="choice choice-1"> <h2>Keuze 1</h2></a>
    <a href="#" class="choice choice-2"> <h2>Keuze 2</h2></a>
    <iframe class ="vimeo" id="player1" src="https://player.vimeo.com/video/119936528?api=1&player_id=player1" width="630" height="354" frameborder="0" ></iframe>

</div>
<div class="vimeo-controls ">
  	<button>Play</button>
  	<button>Pause</button>
</div>