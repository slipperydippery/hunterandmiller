<?php
	$current = 'heemskerkF2';
	require './partials/content.php';
?>