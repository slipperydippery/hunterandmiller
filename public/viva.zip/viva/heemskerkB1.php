<?php
	$current = 'heemskerkB1';
	require './partials/content.php';
?>