<?php
	$current = 'heemskerkE5';
	require './partials/content.php';
?>