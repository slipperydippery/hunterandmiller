<?php
	$current = 'heemskerkA1';
	require './partials/content.php';
?>