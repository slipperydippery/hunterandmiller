<?php
	$current = 'caslimakE4';
	require './partials/content.php';
?>