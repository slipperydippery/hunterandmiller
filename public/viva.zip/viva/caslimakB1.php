<?php
	$current = 'caslimakB1';
	require './partials/content.php';
?>