<?php
	$current = 'heilooD2';
	require './partials/content.php';
?>