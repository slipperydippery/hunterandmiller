<?php
	$current = 'caslimakA1';
	require './partials/content.php';
?>