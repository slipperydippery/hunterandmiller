<?php
	$current = 'beverA1';
	require './partials/content.php';
?>