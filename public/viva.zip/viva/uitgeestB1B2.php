<?php
	$current = 'uitgeestB1B2';
	require './partials/content.php';
?>