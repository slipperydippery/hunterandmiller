<?php
	$current = 'heemskerkE2';
	require './partials/content.php';
?>