<?php
	$current = 'caslimakG0';
	require './partials/content.php';
?>