<?php
	$current = 'heemskerkE6';
	require './partials/content.php';
?>