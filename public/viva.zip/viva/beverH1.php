<?php
	$current = 'beverH1';
	require './partials/content.php';
?>