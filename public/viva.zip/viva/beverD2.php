<?php
	$current = 'beverD2';
	require './partials/content.php';
?>