<?php
	$current = 'caslimakC2';
	require './partials/content.php';
?>