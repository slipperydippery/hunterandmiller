<?php
	$current = 'caslimakE2';
	require './partials/content.php';
?>