<?php
	$current = 'heemskerkD1';
	require './partials/content.php';
?>