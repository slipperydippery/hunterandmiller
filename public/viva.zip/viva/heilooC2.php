<?php
	$current = 'heilooC2';
	require './partials/content.php';
?>