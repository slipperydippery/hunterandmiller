<?php
	$current = 'heemskerkA4';
	require './partials/content.php';
?>