<?php
	$current = 'heilooD1';
	require './partials/content.php';
?>