<?php
	$current = 'heemskerkD3';
	require './partials/content.php';
?>