<?php
	$current = 'beverA4';
	require './partials/content.php';
?>