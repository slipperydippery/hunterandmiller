<?php
	$current = 'heemskerkF3';
	require './partials/content.php';
?>