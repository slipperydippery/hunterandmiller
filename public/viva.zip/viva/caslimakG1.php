<?php
	$current = 'caslimakG1';
	require './partials/content.php';
?>