<?php
	$current = 'heilooG3';
	require './partials/content.php';
?>