<?php
	$current = 'heemskerkA2';
	require './partials/content.php';
?>