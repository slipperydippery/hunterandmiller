<?php
	$current = 'caslimakD3';
	require './partials/content.php';
?>