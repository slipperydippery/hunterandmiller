<?php
	$current = 'beverD1';
	require './partials/content.php';
?>