<?php
	$current = 'caslimak';
	require './partials/content.php';
?>