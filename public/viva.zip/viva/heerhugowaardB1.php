<?php
	$current = 'heerhugowaardB1';
	require './partials/content.php';
?>