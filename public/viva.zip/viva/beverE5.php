<?php
	$current = 'beverE5';
	require './partials/content.php';
?>