<?php
	$current = 'uitgeestC2';
	require './partials/content.php';
?>