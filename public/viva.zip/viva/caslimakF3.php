<?php
	$current = 'caslimakF3';
	require './partials/content.php';
?>