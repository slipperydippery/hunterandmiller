<?php
	$current = 'caslimakA3';
	require './partials/content.php';
?>