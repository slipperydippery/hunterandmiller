<?php
	$current = 'heemskerkA3';
	require './partials/content.php';
?>