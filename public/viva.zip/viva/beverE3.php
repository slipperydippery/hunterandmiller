<?php
	$current = 'beverE3';
	require './partials/content.php';
?>