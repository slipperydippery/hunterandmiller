<?php
	$current = 'heiloo';
	require './partials/content.php';
?>